package com.demo.settings;

import android.content.Context;
import android.util.AttributeSet;

import androidx.preference.SwitchPreference;

public class CouiTimeSwitchPreference extends SwitchPreference {
    public CouiTimeSwitchPreference(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        setLayoutResource(R.layout.layout_time_set);
    }

    public CouiTimeSwitchPreference(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setLayoutResource(R.layout.layout_time_set);
    }

    public CouiTimeSwitchPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
        setLayoutResource(R.layout.layout_time_set);
    }

    public CouiTimeSwitchPreference(Context context) {
        super(context);
        setLayoutResource(R.layout.layout_time_set);
    }
}
