package com.demo.settings;

import android.animation.LayoutTransition;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.Preference;
import androidx.preference.PreferenceCategory;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreference;
import androidx.recyclerview.widget.RecyclerView;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.settings, new SettingsFragment())
                    .commit();
        }
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        Preference date_btn_preference, time_btn_preference ;
        Preference remove_preference;
        Preference sign_preference;
        Preference new_time_preference, new_date_preference;

        PreferenceCategory mCategory;

        @Override
        public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);
            RecyclerView recyclerView = getListView();
            recyclerView.setItemAnimator(null);
        }

        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
            date_btn_preference = findPreference("date_btn");
            time_btn_preference = findPreference("time_btn");


             remove_preference = findPreference("remove");
             sign_preference = findPreference("signature");

            mCategory =  findPreference("first_category");

            new_time_preference = new CouiTimeSwitchPreference(getActivity());
            new_time_preference.setOrder(time_btn_preference.getOrder() +1 );

            new_date_preference = new CouiDateSwitchPreference(getActivity());
            new_date_preference.setOrder(date_btn_preference.getOrder() +1 );




            date_btn_preference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {
                    Toast.makeText(getActivity(), "date add", Toast.LENGTH_SHORT).show();

                    mCategory.addPreference(new_date_preference);
                    mCategory.removePreference(new_time_preference);

                    RecyclerView recyclerView = getListView();
                    recyclerView.getAdapter().notifyDataSetChanged();

                    sign_preference.setVisible(true);
                    return true;
                }
            });
            time_btn_preference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {
                    Toast.makeText(getActivity(), "time add", Toast.LENGTH_SHORT).show();

                    mCategory.addPreference(new_time_preference);
                    mCategory.removePreference(new_date_preference);
                    sign_preference.setVisible(false);
                    RecyclerView recyclerView = getListView();
                    recyclerView.getAdapter().notifyDataSetChanged();

                    return true;
                }
            });
        }
    }
}